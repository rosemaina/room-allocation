unittest2 is a backport of the new features added to the unittest testing
framework in Python 2.7 and 3.2.

This is a Python 3 compatible version of unittest2. Tested with Python 3.0,
3.1 and 3.2.

Although the PyPI project name is "unittest2py3k", the Python package is called
unittest2. Version numbers are the same as the Python 2 unittest2 package.

For full details, including changelog, see:

* `unittest2 on PyPI <http://pypi.python.org/pypi/unittest2>`_

unittest2py3k is maintained in the unittest-ext repository:

* `unittest2py3k svn repository
  <http://code.google.com/p/unittest-ext/source/browse/#svn/trunk/unittest2-py3k>`_
