#! /usr/bin/env python

__unittest = True

from unittest2 import main_

main_()